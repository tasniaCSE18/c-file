#include<stdio.h>
#include<stdlib.h>
int main()
{
    FILE *fp;
    char *p, str[15];
    fp=fopen("my file2.txt","w");

  if(fp==NULL)
  {
      printf("file doesnot exist\n");

  }
  else
  {
      printf("file is opened\n");

  }

fclose(fp);

}
