#include<bits/stdc++.h>
using namespace std;
int main()
{
    ofstream f;
    f.open("fibonacci.txt");
    f.close();
}
