#include<bits/stdc++.h>
#include<fstream>
using namespace std;
int main()
{int n;
    ofstream f("40k.txt");
    f<<n;
    f.close();
}
