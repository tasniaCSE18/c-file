#include<stdio.h>
#include<string.h>
#include<ctype.h>
void f1()
{
    int a[5];
    int n=sizeof(a);
    printf("size:%d",n);
    for(int i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
      for(int i=0;i<n;i++)
    {
        printf("%d\n",a[i]);
    }
}
void f2()
{
    int b[5];
    int n=sizeof(b);
    for(int i=0;i<n;i++)
    {
        scanf("%d",&b[i]);
    }
      for(int i=0;i<n;i++)
    {
        printf("%d\n",b[i]);
    }
}
void f3(int a[5],int b[5])
{int n=sizeof(a);
    int sum[n],s=0;
    int k=n-1,c=0;
    int j=n-1,i=n-1;
  while(j>=0){

          s=a[i]+b[j]+c;
          sum[k]=(s%10);
          c=s/10;
          k--;
          j--;
          i--;
       }

while(i>=0)
{
    s=a[i]+c;
    sum[k]=(s%10);
    c=s/10;
    i--;
    k--;
}

    for(int i=0;i<n;i++)
    {
        printf("%d",sum[i]);
    }



}
int main()
{

f1();
f2();
printf("The summed up array: ");
f3(f1,f2);
}
