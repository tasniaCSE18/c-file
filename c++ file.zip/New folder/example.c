#include<stdio.h>
//char (*ch[6])(int *x[]);

int 	main()
{char p[20];
scanf("%s", &p);
printf("%c", p);

	}



