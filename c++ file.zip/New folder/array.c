#include<stdio.h>
#include<stdlib.h>
int main()
{
    int a,b,x,ar[1000];
    float avg;
    FILE *fp;
    fp=fopen("input.dat","rb");
    while(!feof(fp))
    {

    for(int i=0;i<499;i++)
    {
        fscanf(fp,"%d",&x);
         fscanf(fp,"%d",&a);
    }
    for(int i=500;i<749;i++)
    {
        fscanf(fp,"%d",&x);
        fscanf(fp,"%d",&b);
    }
    }
    avg=(a+b)/2.0;
    printf("%.2f",avg);
    fclose(fp);
}
